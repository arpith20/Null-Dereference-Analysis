package TestCases;

public class PublicTests {
	int i;
	
	public static void main(String[] args) {
		Test1 t1 = new Test1();
		t1.startTest();
		Test2 t2 = new Test2();
		t2.startTest();
		Test3 t3 = new Test3();
		t3.startTest();
		Test4 t4 = new Test4();
		t4.startTest();
		Test5 t5 = new Test5();
		t5.startTest();
	}
}
